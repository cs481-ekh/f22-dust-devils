__author__ = "Lev Nagdimunov"
__copyright__ = "2015 - 2021, University of Maryland"

__version__ = "1.3"
__email__ = "lnagdi1@astro.umd.edu"
