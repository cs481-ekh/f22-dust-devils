The list of contributors can be found `on GitHub <https://github.com/dfm/emcee/graphs/contributors>`_.
